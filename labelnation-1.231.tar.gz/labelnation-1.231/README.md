# Label Nation: print address labels from a command line

Home page: https://red-bean.com/labelnation/

LabelNation is free and open source software for making labels.
By "label", I mean address labels, business cards, or anything else
involving regularly-arranged rectangles on a printer-ready sheet.  You
can give it plain text lines and it will arrange them on the labels in
a reasonable way -- or if you want to get really fancy, you can give
it PostScript, and it will place and clip appropriately for whatever
label size you specified.

This started out as a single PostScript file that printed my name and
address on a sheet of 30 peel-and-stick labels.  Now it's generalized,
with pre-defined configurations for various standard label sizes, and
the ability to define your own standards.  It even accepts input files
with multiple addresses (so you can run a snail-mailing list,
whoo-whee!).

If you read this far, you probably want to know how to use it.  You
can find out more by running this command (at a Unix-like command
prompt, assuming you have Python 3 installed):

      prompt$ labelnation --help | more

## New label parameters and bug reports are welcome.

I'm always interested in contributions of new label parameters, of
course.  Also, bug reports about alignment or sizes being off are very
useful, as I don't have enough experience with other printers to know
that the built-in label standards work everywhere.  I know they work
on _my_ printer, but my printer is an old Okidata emulating an old HP,
and being driven by ghostscript.  Well, okay, that's not true anymore,
but it was when I first wrote LabelNation.  The point is, printers
differ, so if this isn't't working well on yours, I want to know.

## Code Contributions

Please see the [MAINTENANCE](MAINTENANCE.md) file.
